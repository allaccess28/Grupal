Archivo Readme:
	Proyecto  “Evaluación Módulo 2”.
	Descripción del proyecto: el presente proyecto consiste en la realización de páginas entrelazadas que guardan los datos relativos a un sistema de información de una empresa de SST. Dichas páginas tienen como objetivo formar parte de un sitio empresarial de carácter general, que incluirá todos los componentes del presente curso, es decir; tanto front como el backend necesario para su óptima ejecución.
	Estado del proyecto: fase de diseño web. Posterior a la implementación de todos los ajustes y cambios necesarios, se procederá a subirlo a un repositorio github.
	Tecnologías involucradas: hasta ahora sólo se han utilizado HTML y CSS en el desarrollo del proyecto.
	Bugs conocidos: ninguno, la etapa es netamente de diseño web.
	Autores del proyecto:
•	Juan Pablo Olguín.
•	Luís Felipe González.
•	Norberto Molero.
